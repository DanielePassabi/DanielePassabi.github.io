model_info = dict(
    model_path = "../model/knn_data/KNeighborsClassifier_model.sav",
    encod_path = "../model/knn_data/KNeighborsClassifier_encoder.sav",
)